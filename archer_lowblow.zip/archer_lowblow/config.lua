Config = {}

-- Max distance (meters)
Config.MaxDistance = 2.5

-- Cooldown (seconds)
Config.Cooldown = 6

-- Damage
Config.DamageAbsolute = 8
Config.DamagePercent = 0 -- >0 to use percentage of current health

-- Ragdoll time (ms)
Config.VictimRagdollTime = 1600

-- Delay attacker animation -> victim reaction (ms)
Config.VictimAnimDelay = 200

-- Kick emote (replace with your emote dict/name)
Config.KickEmote = {
    dict = "mech_melee@blade@_male@_ambient@_healthy@intimidation@_streamed",
    name = "att_haymaker_head_rightside_dist_near_v1",
    blendIn = 5.0,
    blendOut = 8.0,
    flag = 2
}

-- Optional forward lunge
Config.LungeDistance = 0.7
Config.LungeDuration = 350

-- Camera shake for victim
Config.VictimShake = 0.08

-- Notifications
Config.EnableClientNotifications = false
