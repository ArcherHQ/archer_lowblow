-- Basic configuration. Tweak these values to your server's needs.
Config = {}

-- Max distance (metres) attacker must be from victim to attempt lowblow
Config.MaxDistance = 2.5

-- Cooldown (seconds) between uses per player
Config.Cooldown = 6

-- Minimum server-side permission group required to use the command. Set to nil to allow everyone.
-- Example: if your server uses an admin system, you can check server-side before performing.
Config.RequiredPermission = nil

-- Damage (absolute HP) or percentage mode (set DamagePercent > 0 to use percent)
Config.DamageAbsolute = 8
Config.DamagePercent = 0 -- e.g. 0.08 for 8% of current health

-- Ragdoll & animation timings (milliseconds)
Config.VictimRagdollTime = 1600
Config.VictimAnimDelay = 220 -- delay to play reaction anim after attacker anim starts

-- Animation dictionaries and names (updated to working RDR2 kick + reaction)
Config.AttackAnim = {
    dict = "melee@unarmed@streamed_core_fps",
    name = "kick_front_a",
    blendIn = 8.0,
    blendOut = -8.0,
    flag = 48
}

Config.VictimAnim = {
    dict = "ai_react@react_hit",
    name = "hit_from_front_left",
    blendIn = 8.0,
    blendOut = -8.0,
    duration = 1000,
    flag = 48
}

-- Notification helpers: set to false to disable default chat messages
Config.EnableClientNotifications = true
Config.EnableServerMessages = true
