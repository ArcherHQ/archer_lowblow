local function notify(text)
    if Config.EnableClientNotifications then
        TriggerEvent('chat:addMessage', { args = { '^1LowBlow^7', text } })
    end
end

local function getPlayerPedFromServerId(serverId)
    local player = GetPlayerFromServerId(serverId)
    if not player or player == -1 then return nil end
    return GetPlayerPed(player)
end

RegisterNetEvent('lowblow:requestValidate')
AddEventHandler('lowblow:requestValidate', function(targetServerId)
    local srcPlayer = PlayerId()
    local srcPed = PlayerPedId()

    local targetPed = getPlayerPedFromServerId(targetServerId)
    if not targetPed or not DoesEntityExist(targetPed) then
        notify('Target not found or not nearby.')
        return
    end

    local myCoords = GetEntityCoords(srcPed)
    local targetCoords = GetEntityCoords(targetPed)
    local dist = #(myCoords - targetCoords)
    if dist > Config.MaxDistance then
        notify('Too far away.')
        return
    end

    if not HasEntityClearLosToEntity(srcPed, targetPed, 17) then
        notify('No clear line of sight.')
        return
    end

    local anim = Config.AttackAnim
    RequestAnimDict(anim.dict)
    local t0 = GetGameTimer()
    while not HasAnimDictLoaded(anim.dict) and (GetGameTimer() - t0) < 2000 do
        Citizen.Wait(20)
    end

    TaskPlayAnim(srcPed, anim.dict, anim.name, anim.blendIn, anim.blendOut, -1, anim.flag, 0, false, false, false)

    Citizen.Wait(Config.VictimAnimDelay)

    TriggerServerEvent('lowblow:performValidated', GetPlayerServerId(srcPlayer), targetServerId)
end)

RegisterNetEvent('lowblow:applyOnVictim')
AddEventHandler('lowblow:applyOnVictim', function(attackerServerId)
    local ped = PlayerPedId()

    local vAnim = Config.VictimAnim
    RequestAnimDict(vAnim.dict)
    local t0 = GetGameTimer()
    while not HasAnimDictLoaded(vAnim.dict) and (GetGameTimer() - t0) < 2000 do
        Citizen.Wait(20)
    end

    Citizen.Wait(60)

    if HasAnimDictLoaded(vAnim.dict) then
        TaskPlayAnim(ped, vAnim.dict, vAnim.name, vAnim.blendIn, vAnim.blendOut, vAnim.duration, vAnim.flag, 0, false, false, false)
    else
        ShakeGameplayCam('SMALL_EXPLOSION_SHAKE', 0.08)
    end


    SetPedToRagdoll(ped, Config.VictimRagdollTime, Config.VictimRagdollTime, 0, false, false, false)

    local curHp = GetEntityHealth(ped)
    local dmg = Config.DamageAbsolute
    if Config.DamagePercent and Config.DamagePercent > 0 then
        dmg = math.max(1, math.floor(curHp * Config.DamagePercent))
    end
    local newHp = math.max(1, curHp - dmg)
    SetEntityHealth(ped, newHp)

    notify('You were hit in the groin!')
end)

RegisterNetEvent('lowblow:notify')
AddEventHandler('lowblow:notify', function(msg)
    notify(msg)
end)
