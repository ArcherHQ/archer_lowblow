local function notify(msg)
    if Config.EnableClientNotifications then
        TriggerEvent('chat:addMessage', { args = { '^1LowBlow^7', msg } })
    end
end

local function getPedFromServerId(id)
    local p = GetPlayerFromServerId(id)
    if not p or p == -1 then return nil end
    return GetPlayerPed(p)
end

-- Attacker: validate distance/LOS then play kick animation
RegisterNetEvent('lowblow:requestValidate')
AddEventHandler('lowblow:requestValidate', function(targetServerId)
    local srcPed = PlayerPedId()
    local targetPed = getPedFromServerId(targetServerId)
    if not targetPed or not DoesEntityExist(targetPed) then
        notify("Target not found.")
        return
    end

    local myCoords = GetEntityCoords(srcPed)
    local targetCoords = GetEntityCoords(targetPed)
    local dist = #(myCoords - targetCoords)
    if dist > Config.MaxDistance then
        notify("Too far away.")
        return
    end

    if not HasEntityClearLosToEntity(srcPed, targetPed, 17) then
        notify("No clear line of sight.")
        return
    end

    -- --- Prepare ped for animation ---
    ClearPedTasksImmediately(srcPed)       -- cancel other tasks
    SetCurrentPedWeapon(srcPed, `WEAPON_UNARMED`, true)

    -- Play configured kick animation (same pattern as soccer script)
    local anim = Config.KickEmote
    RequestAnimDict(anim.dict)
    while not HasAnimDictLoaded(anim.dict) do
        Wait(10)
    end
    TaskPlayAnim(srcPed, anim.dict, anim.name, 5.0, 8.0, 1000, 2, 0, false, false, false)

    -- Wait briefly so animation starts before victim ragdoll
    Citizen.Wait(Config.VictimAnimDelay)

    -- Notify server to apply victim effects
    TriggerServerEvent('lowblow:performValidated', GetPlayerServerId(PlayerId()), targetServerId)
end)

-- Victim: ragdoll + shake + damage
RegisterNetEvent('lowblow:applyOnVictim')
AddEventHandler('lowblow:applyOnVictim', function(attackerServerId)
    local ped = PlayerPedId()

    ShakeGameplayCam('SMALL_EXPLOSION_SHAKE', Config.VictimShake)
    SetPedToRagdoll(ped, Config.VictimRagdollTime, Config.VictimRagdollTime, 0, false, false, false)

    local hp = GetEntityHealth(ped)
    local dmg = Config.DamageAbsolute
    if Config.DamagePercent and Config.DamagePercent > 0 then
        dmg = math.max(1, math.floor(hp * Config.DamagePercent))
    end
    SetEntityHealth(ped, math.max(1, hp - dmg))

    notify("You were hit in the groin!")

    -- Stop attacker animation when victim ragdolls
    local attackerPed = getPedFromServerId(attackerServerId)
    if attackerPed and DoesEntityExist(attackerPed) then
        ClearPedTasks(attackerPed)
    end
end)

RegisterNetEvent('lowblow:notify')
AddEventHandler('lowblow:notify', notify)
