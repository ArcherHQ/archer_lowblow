fx_version 'cerulean'
game 'rdr3'

author 'Archer'
description 'Low-blow (groin kick) sync for RedM. Attacker animation + victim reaction, cooldowns, server-side validation.'
version '1.0.0'

server_scripts {
    'server.lua'
}

client_scripts {
    'client.lua'
}

shared_script 'config.lua'
