# RedM Low-Blow Resource

This RedM resource implements a synced "low blow" (groin kick) action: attacker triggers an animation, server validates and triggers victim reaction + damage.

## Installation
1. Create a folder called `redm-lowblow` in your server `resources` directory.
2. Save the files from this package into that folder: `fxmanifest.lua`, `server.lua`, `client.lua`, `config.lua`, `README.md`.
3. Add `ensure redm-lowblow` to your `server.cfg` or start it manually.

## Usage
- In-game, run `/lowblow <playerServerId>` where `<playerServerId>` is the target player's server id (visible in admin/scoreboard tools).

## Notes & Tuning
- The animation dictionary/name values in `config.lua` are placeholders. Test different anims available on RDR2/RedM to find a combination that visually fits your server. If an animation dictionary or name doesn't exist for your client version, the script falls back to a small camera shake + ragdoll.
- The server uses simple cooldowns for anti-abuse, but you should integrate your own permission checks, logging, and roleplay rules.
- If your server uses a custom health/vitals system, replace `GetEntityHealth` / `SetEntityHealth` with your own exports/calls.

## Troubleshooting
- If attacker or victim does not see the correct animations, check that the anim dictionaries exist on the client. Use an in-game dev command to test anims.
- If you experience desyncs, increase `Config.VictimAnimDelay` or adjust timings in `client.lua`.
