local cooldowns = {}

local function now() return os.time() end

RegisterCommand('lowblow', function(source, args)
    local src = source
    local targetId = tonumber(args[1])
    if not targetId or targetId == src then
        if Config.EnableClientNotifications then
            TriggerClientEvent('lowblow:notify', src, "Usage: /lowblow <playerServerId> (can't target yourself)")
        end
        return
    end

    local last = cooldowns[src]
    if last and now() - last < Config.Cooldown then
        local remaining = Config.Cooldown - (now() - last)
        if Config.EnableClientNotifications then
            TriggerClientEvent('lowblow:notify', src, ("Wait %ds before using that again."):format(remaining))
        end
        return
    end

    -- Ask attacker client to validate distance/LOS
    TriggerClientEvent('lowblow:requestValidate', src, targetId)
end, false)

RegisterNetEvent('lowblow:performValidated')
AddEventHandler('lowblow:performValidated', function(attackerId, targetId)
    if not attackerId or not targetId or attackerId == targetId then return end
    cooldowns[attackerId] = now()

    -- trigger victim-side effects
    TriggerClientEvent('lowblow:applyOnVictim', targetId, attackerId)

    -- notify attacker
    if Config.EnableClientNotifications then
        TriggerClientEvent('lowblow:notify', attackerId, "Low-blow executed.")
    end
end)
