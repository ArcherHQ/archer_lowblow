local cooldowns = {}

local function now()
    return os.time()
end

RegisterCommand('lowblow', function(source, args, raw)
    local src = source
    local targetId = tonumber(args[1])

    if not targetId then
        if Config.EnableClientNotifications then
            TriggerClientEvent('lowblow:notify', src, 'Usage: /lowblow <playerServerId>')
        end
        return
    end

    if targetId == src then
        if Config.EnableClientNotifications then
            TriggerClientEvent('lowblow:notify', src, "You can't lowblow yourself.")
        end
        return
    end

    -- cooldown check
    local last = cooldowns[src]
    if last and (now() - last) < Config.Cooldown then
        local remaining = Config.Cooldown - (now() - last)
        if Config.EnableClientNotifications then
            TriggerClientEvent('lowblow:notify', src, ('Wait %ds before using that again.'):format(remaining))
        end
        return
    end


    if Config.RequiredPermission then
        local hasPerm = true
        if not hasPerm then
            if Config.EnableClientNotifications then
                TriggerClientEvent('lowblow:notify', src, 'You do not have permission to use this.')
            end
            return
        end
    end

    TriggerClientEvent('lowblow:requestValidate', src, targetId)
end, false)

RegisterNetEvent('lowblow:performValidated')
AddEventHandler('lowblow:performValidated', function(attackerServerId, targetServerId)
    if attackerServerId == nil or targetServerId == nil then return end
    if attackerServerId == targetServerId then return end

    cooldowns[attackerServerId] = now()

    TriggerClientEvent('lowblow:applyOnVictim', targetServerId, attackerServerId)

    if Config.EnableClientNotifications then
        TriggerClientEvent('lowblow:notify', attackerServerId, 'Low-blow performed.')
    end
end)
